# SQL de auditoría y cajón — 40 a 43

Destino inicial: Supabase de ensayo. Requieren el esquema comercial y migraciones 01–05. SQL39 corresponde al motivo de precios y tiene su paquete independiente. Estos SQL no activan Point ni despliegan Edge Functions.

Ejecutar completos en SQL Editor en este orden:
1. 40_supabase_fase_auditoria_comercial_consulta.sql
2. 41_supabase_fase_apertura_manual_cajon.sql
3. 42_supabase_fase_resultado_apertura_cajon.sql
4. 43_supabase_fase_consulta_auditoria_cajon.sql

Conservar BEGIN/COMMIT. Si alguno falla, detenerse y revisar el error. Pueden reaplicarse en este orden. SQL43 reemplaza la consulta del 40 para incluir cajón; no terminar la instalación reaplicando 40.

El dueño activo consulta auditoría en Configuración → Seguridad y Caja. La apertura manual solicita autorización y motivo antes del pulso. La impresora debe estar autorizada y configurada previamente. El resultado sólo refleja lo declarado por el navegador, no demuestra apertura física. Si el pulso se envió y falla su auditoría, el sistema indica no repetir apertura. No hay recuperación automática del resultado pendiente todavía.

Validación pendiente: dueño/cajero/otro comercio con JWT reales; solicitud y resultado, rechazo de motivos inválidos, reintento sin duplicación y resultado inmutable; impresora y cajón reales, error y desconexión. Las pruebas locales no sustituyen ese piloto. Nunca compartir tokens, secretos ni contraseñas como evidencia.

Ver docs/apertura-manual-cajon.md y docs/auditoria-comercial-consulta.md. Los archivos SHA256 permiten comparar integridad del paquete.